from tkinter import *
from tkinter import ttk,messagebox 
import tkinter
from tkcalendar import Calendar,DateEntry
from DbOperation import DbOperation
import random
import math
class CargoShipment:
     def __init__(self, window, formtitle):
        self.window = window
        self.window.title(formtitle)
        self.window.wm_minsize(500,500)
        self.lb_formtitle = Label(self.window, text="Cargo Shipping",font=("Helvetica", 14)).grid(row=0,column=1)
        self.lb_cargotype = Label(self.window, text="Type of Cargo",).grid(row=1,column=0,sticky=W,padx=15)
        self.cmb_cargotype=ttk.Combobox(self.window,width=20)
        self.cmb_cargotype['values']=('coco beans','sugar','chocolate')
        self.cmb_cargotype.grid(row=1,column=1,padx=10,pady=20) 
        self.cmb_cargotype.current(0)
        self.lb_quantity=Label(self.window, text="Quantity(in tones)",).grid(row=2,column=0,sticky=W,padx=15)
        vcmd = (self.window.register(self.callback), '%S', '%P')
        self.txt_quantity = Entry(self.window, bd =6,validate='key',validatecommand=vcmd)
        self.txt_quantity.grid(row=2,column=1,padx=10,pady=10)
        self.lb_transmode=Label(self.window, text="Preferred mode of Transportation",).grid(row=3,column=0,sticky=W,padx=15)
        #self.txt_transmode = Entry(self.window, bd =6)
        #self.cmb_transmode=ttk.Combobox(self.window,width=20)
        #self.cmb_transmode['values']=('air','road','rail')
        #self.cmb_transmode.grid(row=3,column=1,padx=10,pady=10) 
        #self.cmb_transmode.bind("<<ComboboxSelected>>", self.get_selectedtrans)
        #self.cmb_transmode.current(0)
        self.check_var1 = IntVar()
        self.check_transmode1 = Checkbutton(self.window, text = "Air", variable = self.check_var1, \
                                            width = 20, \
                                           command=self.get_transmode)
        self.check_transmode1.grid(row=4,column=0,padx=10,pady=10)
        self.check_var2 = IntVar()
        self.check_transmode2 = Checkbutton(self.window, text = "Road", variable = self.check_var2, \
                                             width = 20, \
                                           command=self.get_transmode)
        self.check_transmode2.grid(row=4,column=1,padx=10,pady=10)
        self.check_var3 = IntVar()
        self.check_transmode3 = Checkbutton(self.window, text = "Rail", variable = self.check_var3, \
                                             width = 20, \
                                           command=self.get_transmode) 
        self.check_transmode3.grid(row=4,column=2,padx=10,pady=10)                                 
        self.lb_vehicletype=Label(window, text="Type of Vehicle",)
        self.lb_vehicletype.grid_forget()
        self.var = IntVar()
        self.rb_vehicletype1=Radiobutton(window,text="Box Truck",variable=self.var,value = 1,
                                         command=self.get_vehicletype)          
        self.rb_vehicletype1.grid_forget()
        self.rb_vehicletype2=Radiobutton(window,text="Flatbed",variable=self.var,value = 2,
                                         command=self.get_vehicletype)
        self.rb_vehicletype2.grid_forget()
        self.lb_locsource=Label(self.window, text="Pickup Location",).grid(row=6,column=0,sticky=W,padx=15)
        self.cmb_locsource=ttk.Combobox(self.window,width=20)
        self.cmb_locsource['values']=self.getlocation()
        self.cmb_locsource.grid(row=6,column=1,padx=10,pady=10) 
        self.cmb_locsource.current(0)
        self.lb_pickdate=Label(self.window, text="Pickup date",).grid(row=7,column=0,sticky=W,padx=15)
        self.pickdate = DateEntry(self.window,width=19,bg="darkblue",fg="white",year=2020)
        self.pickdate.grid(row=7,column=1,padx=10,pady=10)
        self.lb_picktime=Label(self.window, text="Pickup time",).grid(row=8,column=0,sticky=W,padx=15)
        #self.picktime =  Entry(self.window, bd =5).grid(row=8,column=1,padx=10,pady=10)
        self.picktimehr=Spinbox(self.window, from_= 0, to = 24,width=19)
        self.picktimehr.grid(row=8,column=1,padx=4,pady=10) 
        self.lb_picktime1=Label(self.window, text="Hour:",).grid(row=8,column=1,sticky=E)
        self.picktimemin=Spinbox(self.window, from_= 0, to = 60,width=19)
        self.picktimemin.grid(row=8,column=2)
        self.lb_picktime1=Label(self.window, text="Min",).grid(row=8,column=2,sticky=E)
        self.lb_locdest=Label(self.window, text="Destination Location",).grid(row=9,column=0,sticky=W,padx=15)
        self.cmb_locdest=ttk.Combobox(self.window,width=20)
        self.cmb_locdest['values']=self.getlocation()
        self.cmb_locdest.grid(row=9,column=1,padx=10,pady=10) 
        self.cmb_locdest.bind("<<ComboboxSelected>>", self.get_selected_destination)
        self.cmb_locdest.current(0)  
        self.btn_getfastroute=Button(self.window, text ="Get fastest route",bg="grey",fg="white", \
                                    font=("Helvetica", 12),command =lambda: self.get_route('fast')).grid(row=10,column=1,sticky=W,padx=15,pady=10)
        self.lb_location=Label(self.window,text=" ",fg="blue",font=("Helvetica", 14),wraplength=520)
        #self.lb_location.config(text=self.locations)
        self.lb_location.grid(row=11,column=0,columnspan=3,sticky=W,padx=15,pady=10)
        self.rad_var = IntVar()
        self.rb_use_fastest=Radiobutton(window,text="Use fastest route",variable=self.rad_var,value = 1)  
        self.rb_use_fastest.grid(row=10,column=0,sticky=W,padx=15,pady=10)   
        self.btn_getfuel_efficient=Button(self.window, text ="Get fuel efficient route",bg="grey",fg="white", \
                                    font=("Helvetica", 12),command = lambda: self.get_route('fuel')).grid(row=12,column=1,sticky=W,padx=15,pady=10)
        self.rb_use_fueleff=Radiobutton(window,text="Use fuel effiecient route",variable=self.rad_var,value = 2)  
        self.rb_use_fueleff.grid(row=12,column=0,sticky=W,padx=15,pady=10)
        self.btn_shipcargo=Button(self.window, text ="Ship Cargo",bg="blue",fg="white", \
                                    font=("Helvetica", 12),command =self.submit_details).grid(row=13,column=0,sticky=W,padx=15,pady=10)
        self.btn_back=Button(self.window, text ="Back to main menu",bg="blue",fg="white", \
                                font=("Helvetica", 12),command=self.btn_back).grid(row=13,column=1,sticky=W,padx=15,pady=10)
        #self.btn_back.grid(row=2,column=1,pady=10)  
     def submit_details(self):
         cargo_type=self.cmb_cargotype.get()
         quantity=self.txt_quantity.get()
         transmode=[]
         if self.check_var1.get()==1:
             transmode.append('air')
         if self.check_var2.get()==1:
             transmode.append('road') 
             if self.var.get()==1:
                 vehicle_type='Box Truck'
             elif self.var.get()==2:
                 vehicle_type='Flatbed'
         if self.check_var3.get()==1:
             transmode.append('rail') 
         transmode_string=" "
         transmode_string.join(transmode)  
         print(transmode_string)
         pickup_location=self.cmb_locsource.get()
         destination_location=self.cmb_locdest.get() 
         use_fastest_route=0
         use_fueleff_route=0
         if self.rad_var.get()==1:
             use_fastest_route=1
         if self.rad_var.get()==2:
             use_fueleff_route=1
         pickup_date=self.pickdate.get_date()
         pickup_timehr=self.picktimehr.get()
         pickup_timemin=self.picktimemin.get()
         pickup_time=pickup_timehr+':'+pickup_timemin+':00'
         digits = [i for i in range(0, 10)]
         random_str = ""
         ## we can generate any lenght of string we want
         for i in range(6):
        ## generating a random reference number
        ## if we multiply with 10 it will generate a number between 0 and 10 not including 10
            index = math.floor(random.random() * 10)
            random_str += str(digits[index])
         dbObject=DbOperation()
         query="INSERT INTO  [CargoManagement].[dbo].[Cargo_shipping] VALUES ('%s', '%s', '%s', '%s','%s', '%s', '%s','%s', %s,%s,'%s')" % \
                     (cargo_type, quantity,transmode_string.join(transmode),vehicle_type,pickup_location,pickup_date,pickup_time,destination_location,use_fastest_route,use_fueleff_route,random_str)
         print(query)
         rows_affected=dbObject.insert_value(query)
         if rows_affected!=0:
                result=messagebox.askquestion("Confirm","Successfully saved shipping details.Your reference number is "+random_str+". Please use this number to track the shipping status.Do you want to ship another cargo?")
                if result=='yes':
                    self.window.destroy()
                    window = tkinter.Tk()   
                    CargoShipment(window, "Cargo Management")
                    window.mainloop()
                else:
                    self.window.destroy()
                    from MainMenu import MainMenu
                    window = tk.Tk()   
                    MainMenu(window, "Cargo Main Menu") 
     def callback(self,char, entry_value):
          if str.isdigit(char):
            return True
          else:
            messagebox.showwarning("Warning","Please enter numeric value in quantity field") 
            return False
     def get_vehicletype(self):
         print(self.var.get())
     def get_route(self,button_id):
         pickup_location=self.cmb_locsource.get()
         destination_location=self.cmb_locdest.get()
         if pickup_location==destination_location:
             messagebox.showwarning("Warning","Sorry pickup location and destination locations are same.Please choose different one")
         dbObject=DbOperation()
         query="""(select l.location_id,l.location1,'' as connection,l.location2,l.distance as distance1,'' as distance2,
                l.trans_mode,'' as total,l.distance/50 as 'flatbed_time',l.distance/35 as 'truck_time',
                l.distance/42 as 'train_time',l.distance/550 as 'plane_time',l.distance*2.4 as 'truck_eff',
                l.distance*1.6 as 'flatbed_eff',l.distance*0.8 as 'train_eff',l.distance*4.7 as 'plane_eff' 
                from Location l where (l.location1='"""+pickup_location+"""' and l.location2=
                '"""+destination_location+"""') or (l.location1='"""+destination_location+"""' and l.location2=
                '"""+pickup_location+"""')) union
                (select l1.location_id,l1.location1,l1.location2 as connection,l2.location2,l1.distance as 
                distance1,l2.distance as distance2,l1.trans_mode,(l1.distance+l2.distance) as total,
                (l1.distance+l2.distance)/50 as 'flatbed_time',(l1.distance+l2.distance)/35 as 'truck_time',
                (l1.distance+l2.distance)/42 as 'train_time',(l1.distance+l2.distance)/550 as 'plane_time',
                (l1.distance+l2.distance)*2.4 as 'truck_eff',(l1.distance+l2.distance)*1.6 as 'flatbed_eff',
				(l1.distance+l2.distance)*0.8 as 'train_eff',(l1.distance+l2.distance)*4.7 as 'plane_eff' from Location l1 
                 join Location l2 on (l1.location2=l2.location1 or l2.location2=l1.location1) and 
                 (l1.trans_mode=l2.trans_mode) and((l1.location1='"""+pickup_location+"""' and l2.location2=
                 '"""+destination_location+"""') or (l2.location2='"""+pickup_location+"""' and l1.location1=
                 '"""+destination_location+"""')))"""
        # print(query)
         cursor=dbObject.exec_select_return_result(query)
         cursor.execute(query)
         #print(records["location_id"])
         columns = cursor.description
         all_records = []       
         for value in cursor.fetchall():
            tmp = {}
            for (index,column) in enumerate(value):
                tmp[columns[index][0]] = column
            all_records.append(tmp)
         print(all_records)
         min_flatbed_time = min([record['flatbed_time'] for record in all_records ] )
         min_truck_time = min([record['truck_time'] for record in all_records ] )
         min_train_time = min([record['train_time'] for record in all_records ] )
         min_plane_time = min([record['plane_time'] for record in all_records ] )
         min_flatbed_eff=min([record['flatbed_eff'] for record in all_records ] )
         min_truck_eff = min([record['truck_eff'] for record in all_records ] )
         min_train_eff = min([record['train_eff'] for record in all_records ] )
         min_plane_eff = min([record['plane_eff'] for record in all_records ] )
         total_distance=0
         for record in all_records:
             result=''
             location1=record['location1']
             connection=record['connection']
             location2=record['location2']
             distance1=record['distance1']           
             distance2=record['distance2'] 
             trans_mode=record['trans_mode']
             if button_id=='fast':
                if trans_mode=='road':
                    if self.txt_quantity.get()<='2400':
                        if min_truck_time!=record['truck_time']:                        
                            continue
                        else:
                            expected_vehicle='Box Truck'
                    elif self.txt_quantity.get()<='4500':
                        if min_flatbed_time!=record['flatbed_time']:                          
                            continue
                        else:
                            expected_vehicle+='Flatbed'
                elif trans_mode=='train':
                    if min_train_time!=record['train_time']:                       
                        continue
                    else:
                        expected_vehicle+='Train'
                elif trans_mode=='air':
                    if min_plane_time!=record['plane_time']:                       
                        continue
                    else:
                        expected_vehicle+='Plane'
                if pickup_location in location1:
                    result=location1
                    if connection=='':
                        result=result+'...............'+location2
                    else:
                        result=result+' - '+connection+'...............'+connection+' - '+location2
                else:
                    result=location2
                    if connection=='':
                        result=result+'...............'+location1
                    else:
                        result=result+' - '+connection+'...............'+connection+' - '+location1

                if distance2!='':
                    total_distance=int(distance1)+int(distance2)
                    result=result+'('+str(total_distance)+'Km)'
                else:
                    total_distance=int(distance1)
                    result=result+'('+distance1+'Km)'          
                result=result+'[ via '+trans_mode+' ( '+expected_vehicle+' )]'
                self.lb_location.config(text=result)
             elif button_id=='fuel':
                if trans_mode=='road':
                    if self.txt_quantity.get()<='2400':
                        if min_truck_eff!=record['truck_eff']:                        
                            continue
                        else:
                            fuel_efficient_vehicle='Box Truck'
                    elif self.txt_quantity.get()<='4500':
                        if min_flatbed_eff!=record['flatbed_eff']:                          
                            continue
                        else:
                            fuel_efficient_vehicle='Flatbed'
                elif trans_mode=='train':
                    if min_train_eff!=record['train_eff']:                       
                        continue
                    else:
                        fuel_efficient_vehicle='Train'
                elif trans_mode=='air':
                    if min_plane_eff!=record['plane_eff']:                       
                        continue
                    else:
                        fuel_efficient_vehicle='Plane'
                if pickup_location in location1:
                    result='Most fuel efficient route is '+location1
                    if connection=='':
                        result=result+'...............'+location2
                    else:
                        result=result+' - '+connection+' - '+location2
                else:
                    result=location2
                    if connection=='':
                        result=result+'...............'+location1
                    else:
                        result=result+' - '+connection+' - '+location1
         
                result=result+'.It will be more fuel efiicient if use '+fuel_efficient_vehicle+' for transportation '
                self.lb_location.config(text=result)

     def get_transmode(self):
         if self.check_var2.get()==1:
            self.lb_vehicletype.grid(row=5,column=0)
            self.rb_vehicletype1.grid(row=5,column=1)
            self.rb_vehicletype2.grid(row=5,column=2)
         else:
            self.lb_vehicletype.grid_forget()
            self.rb_vehicletype1.grid_forget()
            self.rb_vehicletype2.grid_forget()
     def getlocation(self):
            dbObject=DbOperation()
            query="select distinct location1 from Location union select distinct location2 from Location"
            result=dbObject.exec_select(query)
            return result
     def get_selected_destination(self,event):
        if self.cmb_locdest.get()==self.cmb_locsource.get():
            messagebox.showwarning("Warning","Sorry pickup location and destination locations are same")
     def btn_back(self):
        from MainMenu import MainMenu
        self.window.destroy()
        window = tkinter.Tk()   
        MainMenu(window, "Cargo Main Menu")   
# window = tkinter.Tk()   
# login = CargoShipment(window, "Cargo Management")
# window.mainloop()