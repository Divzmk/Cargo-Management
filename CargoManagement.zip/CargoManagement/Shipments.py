from tkinter import *
import tkinter as tk
from tkinter import messagebox
from DbOperation import DbOperation
class Shipment(tk.Tk):
    def __init__(self, title="Cargo App", *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)

        self.title(title)
        self.configure(background="Gray")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        master_frame = tk.Frame(self, bd=3, relief=tk.RIDGE)
        master_frame.grid(sticky=tk.NSEW)
        master_frame.columnconfigure(0, weight=1)
        lb_formtitle = tk.Label(master_frame, text="Pending Shipments", font=("Helvetica", 14))
        lb_formtitle.grid(row=0,column=0,columnspan=3,padx=10,pady=10)

        # Create a frame for the canvas and scrollbar(s).
        frame1 = tk.Frame(master_frame)
        frame1.grid(row=3, column=0, sticky=tk.NW,columnspan=2)

        # Add a canvas in that frame.
        canvas = tk.Canvas(frame1, bg="Yellow")
        canvas.grid(row=0, column=0)

        # Create a vertical scrollbar linked to the canvas.
        vsbar = tk.Scrollbar(frame1, orient=tk.VERTICAL, command=canvas.yview)
        vsbar.grid(row=0, column=1, sticky=tk.NS)
        canvas.configure(yscrollcommand=vsbar.set)

        # Create a horizontal scrollbar linked to the canvas.
        hsbar = tk.Scrollbar(frame1, orient=tk.HORIZONTAL, command=canvas.xview)
        hsbar.grid(row=1, column=0, sticky=tk.EW)
        canvas.configure(xscrollcommand=hsbar.set)

        # Create a frame on the canvas to contain the pending shipments.
        shipments_frame = tk.Frame(canvas, bd=2)
        self.lb_cargtype = Label(shipments_frame, text="Cargo Type",fg="white",bg="blue",font=("Bold", 11), width=15,wraplength=100,pady=10)
        self.lb_cargtype.grid(row=1, column=0,pady=20)
        self.lb_quant = Label(shipments_frame, text="Quantity", width=15,fg="white",bg="blue",font=("Bold", 11),pady=10)
        self.lb_quant.grid(row=1, column=1)
        self.lb_trans_mode = Label(shipments_frame, text="Transport Mode", width=15,wraplength=100,fg="white",bg="blue",font=("Bold", 11),pady=10)
        self.lb_trans_mode.grid(row=1, column=2)
        self.lb_vehicle = Label(shipments_frame, text="Vehicle Preferred", width=15,wraplength=100,fg="white",bg="blue",font=("Bold", 11))
        self.lb_vehicle.grid(row=1, column=3)
        self.lb_pickloc = Label(shipments_frame, text="Pickup Location", width=15,wraplength=100,fg="white",bg="blue",font=("Bold", 11),pady=10)
        self.lb_pickloc.grid(row=1, column=4)
        self.lb_pickdate = Label(shipments_frame, text="Pickup Data & Time", width=15,fg="white",bg="blue",font=("Bold", 11),pady=10)
        self.lb_pickdate.grid(row=1, column=5)
        self.lb_destloc = Label(shipments_frame, text="Destination Location", width=15,wraplength=100,fg="white",bg="blue",font=("Bold", 11),pady=10)
        self.lb_destloc.grid(row=1, column=6)
        self.lb_isfastest = Label(shipments_frame, text="Is fastest route Preferred", width=15,wraplength=100,fg="white",bg="blue",font=("Bold", 11))
        self.lb_isfastest.grid(row=1, column=7)
        self.lb_isfueleff = Label(shipments_frame, text="Is fuel efficient route preferred", width=15,wraplength=100,fg="white",bg="blue",font=("Bold", 11),pady=10)
        self.lb_isfueleff.grid(row=1, column=8)
        self.lb_refno = Label(shipments_frame, text="Reference No:", width=15,wraplength=100,fg="white",bg="blue",font=("Bold", 11),pady=10)
        self.lb_refno.grid(row=1, column=9)
        self.lb_operation = Label(shipments_frame, text="Operation", width=15,wraplength=100,fg="white",bg="blue",font=("Bold", 11),pady=10)
        self.lb_operation.grid(row=1, column=10)
        self.fetchall_pending_shipments(shipments_frame)
        # Create canvas window to hold the buttons_frame.
        canvas.create_window((0,0), window=shipments_frame, anchor=tk.NW)

        shipments_frame.update_idletasks()  # Needed to make bbox info available.
        bbox = canvas.bbox(tk.ALL)  # Get bounding box of canvas with Buttons.

        # Define the scrollable region as entire canvas with only the desired
        # number of rows and columns displayed.
        canvas.configure(scrollregion=bbox, width=700, height=400)
    def fetchall_pending_shipments(self,frame1):
         """Function to fetch all pending shipments and update the status"""
        query="select * from [dbo].[Cargo_shipping] where ref_no not in(select distinct ref_no from Shipping)"
        dbObject=DbOperation()
        cursor=dbObject.exec_select_return_result(query)
        cursor.execute(query)
        data=cursor.fetchall()
        for index, dat in enumerate(data,start=1):
            Label(frame1, text=dat[1]).grid(row=index+1, column=0)
            Label(frame1, text=dat[2]+"Kg").grid(row=index+1, column=1)
            Label(frame1, text=dat[3].title()).grid(row=index+1, column=2)
            Label(frame1, text=dat[4]).grid(row=index+1, column=3)
            Label(frame1, text=dat[5]).grid(row=index+1, column=4)
            pickday=dat[6].strftime("%d-%m-%Y")
            picktime=dat[7].strftime("%H:%M:%S")            
            pickdate=pickday+' '+picktime
            Label(frame1, text=pickdate).grid(row=index+1, column=5)
            self.btn_edit=Button(frame1, text ="Edit",bg="grey",fg="white", font=("Helvetica", 11),command = lambda i=dat[0]: self.edit_values(i))
            self.btn_edit.grid(row=index+1,column=5,pady=10)  