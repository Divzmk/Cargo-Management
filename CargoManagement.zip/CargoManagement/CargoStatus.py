from tkinter import *
import tkinter
from tkinter import ttk,messagebox
from DbOperation import DbOperation
class CargoStatus:
    """This class can be used to display the status of shipping"""
    def __init__(self, window, formtitle):
        self.window = window
        self.window.title(formtitle)
        self.window.wm_minsize(500,500)
        self.lb_formtitle = Label(self.window, text="Shipping Status",font=("Helvetica", 14)).grid(row=0,column=1,pady=10)
        self.lb_refno = Label(self.window, text="Select reference number",).grid(row=1,column=0,sticky=W,padx=15,pady=10)
        self.cmb_refno = ttk.Combobox(self.window,width=20)
        self.cmb_refno['values']=self.getallrefnos()
        self.cmb_refno.grid(row=1,column=1,padx=10,pady=10)
        self.cmb_refno.current(0)
        Button(self.window, text ="Check Status",bg="grey",fg="white", \
                                font=("Helvetica", 12),command = self.check_status).grid(row=2,column=0,padx=10,pady=15)
        Button(self.window, text ="Back to main menu",bg="grey",fg="white", \
                                font=("Helvetica", 12),command=self.btn_back).grid(row=2,column=1,padx=10,columnspan=2,pady=15)
        self.lb_startloc=Label(self.window,text=" ",fg="blue",font=("Helvetica", 14))
        self.lb_startloc.grid(row=3,column=0,sticky=W)
        self.lb_currentloc=Label(self.window,text=" ",fg="red",font=("Helvetica", 14))
        self.lb_currentloc.grid(row=3,column=1,sticky=W)
        self.lb_destloc=Label(self.window,text=" ",fg="blue",font=("Helvetica", 14))
        self.lb_destloc.grid(row=3,column=2,sticky=W)
    def getallrefnos(self):
        dbObject=DbOperation()
        query="select [ref_no] from Cargo_shipping"
        result=dbObject.exec_select(query)
        return result
    def check_status(self):
        query="SELECT * FROM [dbo].[Shipping] where ref_no="+str(self.cmb_refno.get())
        dbObject=DbOperation()
        cursor=dbObject.exec_select_return_result(query)
        cursor.execute(query)
        data=cursor.fetchall()
        if data:
            query="select c.*,s.* from Cargo_shipping c join Shipping s on c.ref_no=s.ref_no where c.ref_no="+str(self.cmb_refno.get())
            cursr=dbObject.exec_select_return_result(query)
            cursr.execute(query)
            data=cursr.fetchall()
            startloc,currentloc,destloc='','',''
            for dat in data:
                startloc=dat[5]+'............................'
                currentloc='...........'+dat[15]+'...........'
                destloc='..........'+dat[8]
                self.lb_startloc.config(text=startloc)
                self.lb_currentloc.config(text=currentloc)
                self.lb_destloc.config(text=destloc)
                cargo=': '+dat[1].title()
                quant=': '+dat[2]+'Kg'
                trans=': '+dat[3].title()
                picktime=dat[17].strftime("%H:%M:%S")
                pickday=dat[16].strftime("%d-%m-%Y")
                pickdate=': '+pickday+' '+picktime
                destime=dat[19].strftime("%H:%M:%S")
                destday=dat[18].strftime("%d-%m-%Y")
                destdate=': '+destday+destime       
                Label(self.window,text="(Pickup Location)",font=("Helvetica", 14)).grid(row=4,column=0,sticky=W)
                Label(self.window,text="(Current Location)",font=("Helvetica", 14)).grid(row=4,column=1,sticky=W)
                Label(self.window,text="(Dest Location)",font=("Helvetica", 14)).grid(row=4,column=2,sticky=W)
                Label(self.window, text="Cargo Name",font=("Helvetica", 12),).grid(row=5,column=0,sticky=W,padx=15)
                Label(self.window, text="Quantity",font=("Helvetica", 12)).grid(row=6,column=0,sticky=W,padx=15)
                Label(self.window, text="Transport Mode",font=("Helvetica", 12)).grid(row=7,column=0,sticky=W,padx=15)
                Label(self.window, text="Pickup Date&Time",font=("Helvetica", 12)).grid(row=8,column=0,sticky=W,padx=15)
                Label(self.window, text="Estimated Date & Time",font=("Helvetica", 12)).grid(row=9,column=0,sticky=W,padx=15)
                # Label(self.window, text="Destination Location",font=("Helvetica", 12)).grid(row=10,column=0,sticky=W,padx=15)
                self.lb_cargoname=Label(self.window, text="",font=("Helvetica", 12))
                self.lb_cargoname.grid(row=5,column=1,sticky=W,padx=15,pady=10)
                self.lb_quantity=Label(self.window, text="",font=("Helvetica", 12))
                self.lb_quantity.grid(row=6,column=1,sticky=W,padx=15,pady=10)
                self.lb_mode=Label(self.window, text="",font=("Helvetica", 12))
                self.lb_mode.grid(row=7,column=1,sticky=W,padx=15,pady=10)
                self.lb_pick=Label(self.window, text="",font=("Helvetica", 12))
                self.lb_pick.grid(row=8,column=1,sticky=W,padx=15,pady=10)
                self.lb_est=Label(self.window, text="",font=("Helvetica", 12))
                self.lb_est.grid(row=9,column=1,sticky=W,padx=15,pady=10)
                # self.lb_dest=Label(self.window, text="",font=("Helvetica", 12))
                # self.lb_dest.grid(row=10,column=1,sticky=W,padx=15,pady=10)
                self.lb_cargoname.config(text=cargo)
                self.lb_quantity.config(text=quant)
                self.lb_mode.config(text=trans)
                self.lb_pick.config(text=pickdate)
                self.lb_est.config(text=destdate)
                #self.lb_dest.config(text=destlo)
        else:
             messagebox.showinfo("Info","Sorry the cargo not dispatched yet")

    def btn_back(self):
        from MainMenu import MainMenu
        self.window.destroy()
        window = tkinter.Tk()   
        MainMenu(window, "Cargo Main Menu")   

# window = tkinter.Tk()   
# CargoStatus(window, "Shipping Status")
# window.mainloop()