from tkinter import *
import tkinter
from tkinter import messagebox
from DbOperation import DbOperation
class Register:
    def __init__(self, window, formtitle):
        self.window = window
        self.window.title(formtitle)
        self.window.wm_minsize(500,500)
        self.lb_formtitle = Label(self.window, text="Signup",font=("Helvetica", 14)).grid(row=0,column=1)
        self.lb_name = Label(self.window, text="Name",).grid(row=1,column=0,sticky=W,padx=15)
        self.lb_emailid = Label(self.window, text="Email",).grid(row=2,column=0,sticky=W,padx=15)
        self.lb_username = Label(self.window, text="Username",).grid(row=3,column=0,sticky=W,padx=15)
        self.lb_password = Label(self.window, text="Password",).grid(row=4,column=0,sticky=W,padx=15)
        self.lb_repassword = Label(self.window, text="Confirm Password",).grid(row=5,column=0,sticky=W,padx=15)
        #self.L4 = Label(self.window, text="a",).grid(row=1,column=2)
        #self.L5 = Label(self.window, text="b",).grid(row=2,column=2)
        self.txt_name = Entry(self.window, bd =5)
        self.txt_name.grid(row=1,column=1,padx=10,pady=10)
        self.txt_emailid = Entry(self.window, bd =5)
        self.txt_emailid.grid(row=2,column=1,padx=10,pady=10)
        self.txt_username = Entry(self.window, bd =5)
        self.txt_username.grid(row=3,column=1,padx=10,pady=10)
        self.txt_password = Entry(self.window,show="*", bd =5)
        self.txt_password.grid(row=4,column=1,padx=10,pady=10)
        self.txt_repassword = Entry(self.window,show="*", bd =5)
        self.txt_repassword.grid(row=5,column=1,padx=10,pady=10)
        self.btn_register=Button(self.window, text ="Register",bg="grey",fg="white", \
                                font=("Helvetica", 12),command = self.register).grid(row=6,column=1,)  
    def register(self):
        name=self.txt_name.get()
        email=self.txt_emailid.get()
        username=self.txt_username.get()
        password=self.txt_password.get()
        re_password=self.txt_repassword.get()
        if password!=re_password:
            messagebox.showwarning("Warning","Passwords not matching")
        else:
            dbObject=DbOperation()
            query = "INSERT INTO  [CargoManagement].[dbo].[User] VALUES ('%s', '%s', '%s', '%s')" % \
                     (username, password,name,email)
            rows_affected=dbObject.insert_value(query)
            if rows_affected!=0:
                messagebox.showinfo("Info","Successfully registered")
                self.window.destroy()
                from Login import LoginForm
                window = tkinter.Tk()   
                login = LoginForm(window, "Cargo Management")
                window.mainloop()
