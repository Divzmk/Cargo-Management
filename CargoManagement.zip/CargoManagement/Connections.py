import tkinter as tk
from tkinter import messagebox
from DbOperation import DbOperation
from tkinter import *


class Connections(tk.Tk):
    def __init__(self, title="Sample App", *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)

        self.title(title)
        self.configure(background="Gray")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        master_frame = tk.Frame(self, bd=3, relief=tk.RIDGE)
        master_frame.grid(sticky=tk.NSEW)
        master_frame.columnconfigure(0, weight=1)
        lb_formtitle = tk.Label(master_frame, text="Available connections", font=("Helvetica", 14))
        lb_formtitle.grid(row=0,column=0,columnspan=3,padx=10,pady=10)

        # Create a frame for the canvas and scrollbar(s).
        frame2 = tk.Frame(master_frame)
        frame2.grid(row=3, column=0, sticky=tk.NW,columnspan=2)

        # Add a canvas in that frame.
        canvas = tk.Canvas(frame2, bg="Yellow")
        canvas.grid(row=0, column=0)

        # Create a vertical scrollbar linked to the canvas.
        vsbar = tk.Scrollbar(frame2, orient=tk.VERTICAL, command=canvas.yview)
        vsbar.grid(row=0, column=1, sticky=tk.NS)
        canvas.configure(yscrollcommand=vsbar.set)

        # Create a horizontal scrollbar linked to the canvas.
        hsbar = tk.Scrollbar(frame2, orient=tk.HORIZONTAL, command=canvas.xview)
        hsbar.grid(row=1, column=0, sticky=tk.EW)
        canvas.configure(xscrollcommand=hsbar.set)

        # Create a frame on the canvas to contain the connections data.
        connections_frame = tk.Frame(canvas, bd=2)
        self.lb_loc1 = Label(connections_frame, text="Location 1",fg="white",bg="blue",font=("Bold", 11), width=15,wraplength=100,pady=10)
        self.lb_loc1.grid(row=1, column=0,pady=20)
        self.lb_loc2 = Label(connections_frame, text="Location 2", width=15,fg="white",bg="blue",font=("Bold", 11),pady=10)
        self.lb_loc2.grid(row=1, column=1)
        self.lb_distance = Label(connections_frame, text="Distance", width=15,wraplength=100,fg="white",bg="blue",font=("Bold", 11),pady=10)
        self.lb_distance.grid(row=1, column=2)
        self.lb_trans_mode = Label(connections_frame, text="Transport mode", width=15,wraplength=100,fg="white",bg="blue",font=("Bold", 11))
        self.lb_trans_mode.grid(row=1, column=3)
        self.lb_operation = Label(connections_frame, text="Operation", width=15,wraplength=100,fg="white",bg="blue",font=("Bold", 11),pady=10)
        self.lb_operation.grid(row=1, column=5)
        self.fetchall_connections(connections_frame)
        # Create canvas window to hold the buttons_frame.
        canvas.create_window((0,0), window=connections_frame, anchor=tk.NW)

        connections_frame.update_idletasks()  # Needed to make bbox info available.
        bbox = canvas.bbox(tk.ALL)  # Get bounding box of canvas with Buttons.

        # Define the scrollable region as entire canvas with only the desired
        # number of rows and columns displayed.
        canvas.configure(scrollregion=bbox, width=700, height=400)
        frame3 = tk.Frame(master_frame)
        frame3.grid(row=5, column=0)
        self.btn_new=Button(frame3, text ="Add new Connection",bg="grey",fg="white", font=("Helvetica", 11),command = self.add_connection_window)
        self.btn_new.grid(row=0,column=1,pady=10,padx=10) 
        self.btn_back=Button(frame3, text ="Back to main menu",bg="grey",fg="white", \
                                font=("Helvetica", 12),command=self.btn_back)
        self.btn_back.grid(row=0,column=2,pady=10,columnspan=2)  
    def fetchall_connections(self,frame1):
        """Function to fetch all available locations and transport mode"""
        query="SELECT * FROM [dbo].[Location]"
        dbObject=DbOperation()
        cursor=dbObject.exec_select_return_result(query)
        cursor.execute(query)
        data=cursor.fetchall()
        for index, dat in enumerate(data,start=1):
            Label(frame1, text=dat[1]).grid(row=index+1, column=0)
            Label(frame1, text=dat[2]).grid(row=index+1, column=1)
            Label(frame1, text=dat[3]).grid(row=index+1, column=2)
            Label(frame1, text=dat[4]).grid(row=index+1, column=3)
            self.btn_edit=Button(frame1, text ="Edit",bg="grey",fg="white", font=("Helvetica", 11),command = lambda i=dat[0]: self.edit_values(i))
            self.btn_edit.grid(row=index+1,column=5,pady=10)  
    def add_connection_window(self):
        self.destroy()
        window = tk.Tk() 
        ConnectionAdd(window,"Add New connection")
        print(self)
    def edit_values(self,loc_id):
        self.destroy()
        window = tk.Tk() 
        ConnectionEdit(window,"Edit Facility",loc_id)
    def btn_back(self):
        from MainMenu import MainMenu
        self.destroy()
        window = tk.Tk()   
        MainMenu(window, "Cargo Main Menu") 
class ConnectionEdit:
    """ConnectionEdit class can be used to edit particular connection"""
    def __init__(self, window, formtitle,loc_id):
        self.window = window
        self.window.title(formtitle)
        self.window.wm_minsize(550,550)
        self.lb_formtitle = Label(self.window, text="Edit connection",font=("Helvetica", 14)).grid(row=0,column=1)
        self.lb_loc1 = Label(self.window, text="Location 1", )
        self.lb_loc1.grid(row=1, column=0,sticky=W,padx=15)
        self.lb_loc2 = Label(self.window, text="Location 2",)
        self.lb_loc2.grid(row=2, column=0,sticky=W,padx=15)
        self.lb_distance = Label(self.window, text="Distance",)
        self.lb_distance.grid(row=3, column=0,sticky=W,padx=15)
        self.lb_trans_mode = Label(self.window, text="Transport Mode",)
        self.lb_trans_mode.grid(row=4, column=0,sticky=W,padx=15)
        self.btn_save=Button(self.window, text ="Save",bg="grey",fg="white", font=("Helvetica", 11),command = lambda: self.button_event('save',loc_id))
        self.btn_save.grid(row=6,column=0,pady=10)  
        self.btn_back=Button(self.window, text ="Back to list",bg="grey",fg="white", font=("Helvetica", 11),command = lambda: self.button_event('back',loc_id))
        self.btn_back.grid(row=6,column=1,pady=10,padx=20)
        fetched_location=self.fetch_loc_byid(loc_id)
        for location in fetched_location:
            self.txt_loc1 = Entry(self.window, bd =5)
            self.txt_loc1.grid(row=1,column=1,padx=10,pady=10)
            self.txt_loc1.insert(0,location[1])
            self.txt_loc2 = Entry(self.window, bd =5)
            self.txt_loc2.grid(row=2,column=1,padx=10,pady=10)
            self.txt_loc2.insert(0,location[2])
            self.txt_distance = Entry(self.window, bd =5)
            self.txt_distance.grid(row=3,column=1,padx=10,pady=10)
            self.txt_distance.insert(0,location[3])
            self.txt_trans_mode = Entry(self.window, bd =5)
            self.txt_trans_mode.grid(row=4,column=1,padx=10,pady=10)
            self.txt_trans_mode.insert(0,location[4])
    def fetch_loc_byid(self,loc_id):
        query="SELECT * FROM [dbo].[Location] where location_id="+str(loc_id)
        dbObject=DbOperation()
        cursor=dbObject.exec_select_return_result(query)
        cursor.execute(query)
        data=cursor.fetchall()
        return data
    def button_event(self,button_id,loc_id):
        if button_id=='save':
            query="update [dbo].[Location] set [location1]='%s',[location2]='%s',[distance]='%s',[trans_mode]='%s' where [location_id]=%d" % \
                  (self.txt_loc1.get(),self.txt_loc2.get(),self.txt_distance.get(),self.txt_trans_mode.get(),loc_id)
            dbObject=DbOperation()
            rows_affected=dbObject.insert_value(query)
            if rows_affected!=0:
                messagebox.showinfo("Info","Successfully saved the changes")
                self.window.destroy()
                Connections("Available connections")
            else:
                messagebox.showinfo("Info","Sorry something went wrong")
        elif button_id=='back':
            self.window.destroy()
            Connections("Available connection")

class ConnectionAdd:
    """ConnectionAdd class can be used to add new connection"""
    def __init__(self, window, formtitle):
        self.window = window
        self.window.title(formtitle)
        self.window.wm_minsize(500,400)
        self.lb_formtitle = Label(self.window, text="Add New Connection",font=("Helvetica", 14)).grid(row=0,column=1)
        self.lb_loc1 = Label(self.window, text="Location 1", )
        self.lb_loc1.grid(row=1, column=0,sticky=W,padx=15)
        self.txt_loc1 = Entry(self.window, bd =5)
        self.txt_loc1.grid(row=1,column=1,padx=10,pady=10)
        self.lb_loc2 = Label(self.window, text="Location 2",)
        self.lb_loc2.grid(row=2, column=0,sticky=W,padx=15)
        self.txt_loc2 = Entry(self.window, bd =5)
        self.txt_loc2.grid(row=2,column=1,padx=10,pady=10)
        self.lb_distance = Label(self.window, text="Distance",)
        self.lb_distance.grid(row=3, column=0,sticky=W,padx=15)
        self.txt_distance = Entry(self.window, bd =5)
        self.txt_distance.grid(row=3,column=1,padx=10,pady=10)
        self.lb_trans_mode = Label(self.window, text="Transport Mode",)
        self.lb_trans_mode.grid(row=4, column=0,sticky=W,padx=15)
        self.txt_trans_mode = Entry(self.window, bd =5)
        self.txt_trans_mode.grid(row=4,column=1,padx=10,pady=10)
        self.btn_save=Button(self.window, text ="Save",bg="grey",fg="white", font=("Helvetica", 11),command = lambda: self.btn_add_connection('save1'))
        self.btn_save.grid(row=5,column=0,pady=10) 
        self.btn_back=Button(self.window, text ="Back to list",bg="grey",fg="white", font=("Helvetica", 11),command = lambda: self.btn_add_connection('back1'))
        self.btn_back.grid(row=5,column=1,pady=10,padx=20)
    def btn_add_connection(self,button_id):
        if button_id=='save1':
            dbObject=DbOperation()
            query="INSERT INTO [dbo].[Location] VALUES ('%s', '%s', %f, '%s')" % \
            (self.txt_loc1.get(),self.txt_loc2.get(),float(self.txt_distance.get()),self.txt_trans_mode.get())
            rows_affected1=dbObject.insert_value(query)
            if rows_affected1!=0:
                messagebox.showinfo("Info","New connection added successfully")
                self.window.destroy()
                Connections("Available connections")
            else:
                messagebox.showinfo("Info","Sorry something went wrong")
        elif(button_id=='back1'):
            self.window.destroy()
            Connections("Available connection")