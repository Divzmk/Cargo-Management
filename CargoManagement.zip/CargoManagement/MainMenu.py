from tkinter import *
import tkinter
from tkinter import messagebox
class MainMenu:
    """This class is used to display all the options related to cargo management.Output window
    acts as the main menu, to where user redirects after successful login"""
    def __init__(self, window, formtitle):
        self.window = window
        self.window.title(formtitle)
        self.window.wm_minsize(500,500)
        self.lb_formtitle = Label(self.window, text="Main Menu",font=("Helvetica", 14)).grid(row=0,column=1,padx=10,pady=10)
        self.btn_shipcargo=Button(self.window, text ="Ship Cargo",bg="grey",fg="white", \
                                font=("Helvetica", 12),command = lambda: self.btn_clicked('ship')).grid(row=1,column=0,padx=10)  
        self.btn_stockview=Button(self.window, text ="View stock",bg="black",fg="white", \
                                font=("Helvetica", 12),command = lambda: self.btn_clicked('stock')).grid(row=1,column=1,)
        self.btn_facview=Button(self.window, text ="View facilities",bg="grey",fg="white", \
                                font=("Helvetica", 12),command = lambda: self.btn_clicked('fac')).grid(row=1,column=2,padx=10)  
        self.btn_facview=Button(self.window, text ="View Connections",bg="black",fg="white", \
                                font=("Helvetica", 12),command = lambda: self.btn_clicked('con')).grid(row=2,column=0,padx=10,pady=10) 
        self.btn_checkstat=Button(self.window, text ="Check Cargo status",bg="grey",fg="white", \
                                font=("Helvetica", 12),command = lambda: self.btn_clicked('stat')).grid(row=2,column=1,padx=10,pady=10)                           
    def btn_clicked(self,btn_id):
        if btn_id=='ship':
            from CargoShipment import CargoShipment
            self.window.destroy()
            window = tkinter.Tk()   
            CargoShipment(window, "Cargo Management")
            # window.mainloop()  
        elif btn_id=='stock':
            from DepotStock import DepotStock
            self.window.destroy()
            window = tkinter.Tk()   
            DepotStock(window, "Depot stock levels")
            # window.mainloop()
        elif btn_id=='fac':
            from Facilities import Facilities
            self.window.destroy()
            window = tkinter.Tk()   
            Facilities(window, "Available facilities")
            # window.mainloop()
        elif btn_id=='con':
            from Connections import Connections
            self.window.destroy()
            Connections("Available connections")
        elif btn_id=='stat':
            from CargoStatus import CargoStatus
            self.window.destroy()
            window = tkinter.Tk()  
            CargoStatus(window, "Shipping Status")
          