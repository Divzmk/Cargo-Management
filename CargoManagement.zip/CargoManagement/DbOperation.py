import pyodbc 
class DbOperation:
# Some other example server values are
# server = 'localhost\sqlexpress' # for a named instance
# server = 'myserver,port' # to specify an alternate port
    def __init__(self):
        self.server = 'USER-PC\SQLEXPRESS' 
        self.database = 'CargoManagement' 
        self.username = 'sa' 
        self.password = 'sql2020' 
    
    def exec_select(self,query):
        cnxn = pyodbc.connect('DRIVER={ODBC Driver 11 for SQL Server};SERVER='+self.server+';DATABASE='+self.database+';UID='+self.username+';PWD='+ self.password)
        cursor = cnxn.cursor()
        cursor.execute(query) 
        result = []
        for row in cursor.fetchall():
            result.append(row[0])

        return result
    def exec_select_return_result(self,query):
        cnxn = pyodbc.connect('DRIVER={ODBC Driver 11 for SQL Server};SERVER='+self.server+';DATABASE='+self.database+';UID='+self.username+';PWD='+ self.password)
        cursor = cnxn.cursor()
        #cursor.execute(query) 
        #records = cursor.fetchall()
        return cursor
    def insert_value(self,query):
        cnxn = pyodbc.connect('DRIVER={ODBC Driver 11 for SQL Server};SERVER='+self.server+';DATABASE='+self.database+';UID='+self.username+';PWD='+ self.password)
        cursor = cnxn.cursor()
        cursor.execute(query)
        cursor.commit()
        return cursor.rowcount
            