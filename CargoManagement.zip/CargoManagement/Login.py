from tkinter import *
import tkinter
from tkinter import messagebox
from DbOperation import DbOperation
from Register import Register
from MainMenu import MainMenu
class LoginForm:
    """This class can be used to display the login form and for loggedin to the application"""
    def __init__(self, window, formtitle):
        self.window = window
        self.window.title(formtitle)
        self.window.wm_minsize(500,500)
        self.lb_formtitle = Label(self.window, text="Login Form",font=("Helvetica", 14)).grid(row=0,column=1)
        self.lb_username = Label(self.window, text="Username",).grid(row=1,column=0,sticky=W,padx=15)
        self.lb_password = Label(self.window, text="Password",).grid(row=2,column=0,sticky=W,padx=15)
        #self.L4 = Label(self.window, text="a",).grid(row=1,column=2)
        #self.L5 = Label(self.window, text="b",).grid(row=2,column=2)
        self.txt_username = Entry(self.window, bd =5)
        self.txt_username.grid(row=1,column=1,padx=10,pady=10)
        self.txt_password = Entry(self.window,show="*", bd =5)
        self.txt_password.grid(row=2,column=1,padx=10,pady=10)
        self.btn_submit=Button(self.window, text ="Signin",bg="grey",fg="white", \
                                font=("Helvetica", 12),command = self.validate_login_details).grid(row=5,column=0,)
        self.btn_register=Button(self.window, text ="Register",bg="grey",fg="white", \
                                font=("Helvetica", 12),command = self.register).grid(row=5,column=1,)    
    def validate_login_details(self):
        """This method can be used to validate the inputs and check whether the fields are empty"""
        username=self.txt_username.get()
        password=self.txt_password.get()
        if username is None or username=='':
            messagebox.showwarning("Warning","Please enter a valid username")
        elif password is None or password=='':
            messagebox.showwarning("Warning","Please enter a valid password")
        else:    
            dbObject=DbOperation()
            query="select * from [dbo].[User] where [username]='%s' and [password]='%s' " % (username,password)
            result=dbObject.exec_select(query)
            if result:
                self.window.destroy()
                window = tkinter.Tk()   
                MainMenu(window, "Cargo Main Menu")           
            else:
                messagebox.showwarning("Warning","Sorry username or password is incorrect.Please try again")
    def register(self):
        """This method handles the click event of the Register button """
        self.window.destroy()
        window = tkinter.Tk()   
        Register(window, "Signup")
        #window.mainloop()
window = tkinter.Tk()   
login = LoginForm(window, "Cargo Management")
window.mainloop()