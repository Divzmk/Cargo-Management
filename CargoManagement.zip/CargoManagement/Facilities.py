from tkinter import *
import tkinter
from tkinter import messagebox
from DbOperation import DbOperation
from MainMenu import MainMenu
class Facilities:
    """Facilities class can be used to view all the facilities"""
    def __init__(self, window, formtitle):
        self.window = window
        self.window.title(formtitle)
        self.window.wm_minsize(700,700)
        self.lb_formtitle = Label(self.window, text="Available facilities",font=("Helvetica", 14)).grid(row=0,column=1,columnspan=3,padx=10,pady=10)
        self.lb_facitype = Label(self.window, text="Type of Facility",fg="white",bg="blue",font=("Bold", 11), width=15,wraplength=100,pady=10)
        self.lb_facitype.grid(row=1, column=0,pady=20)
        self.lb_name = Label(self.window, text="Name", width=20,fg="white",bg="blue",font=("Bold", 11),pady=10)
        self.lb_name.grid(row=1, column=1)
        self.lb_connection = Label(self.window, text="Connection", width=15,fg="white",bg="blue",font=("Bold", 11),pady=10)
        self.lb_connection.grid(row=1, column=2)
        self.lb_distance = Label(self.window, text="Distance to Connection", width=15,wraplength=100,fg="white",bg="blue",font=("Bold", 11))
        self.lb_distance.grid(row=1, column=3)
        self.lb_connection_type = Label(self.window, text="Type of Connection", width=15,wraplength=100,fg="white",bg="blue",font=("Bold", 11))
        self.lb_connection_type.grid(row=1, column=4)
        self.lb_operation = Label(self.window, text="Operation", width=15,wraplength=100,fg="white",bg="blue",font=("Bold", 11),pady=10)
        self.lb_operation.grid(row=1, column=5)
        self.fetchallfacilities()
    def fetchallfacilities(self):
        """Function to fetch all facility related data from database table Facility"""
        query="SELECT * FROM [dbo].[Facility]"
        dbObject=DbOperation()
        cursor=dbObject.exec_select_return_result(query)
        cursor.execute(query)
        data=cursor.fetchall()
        for index, dat in enumerate(data,start=1):
            Label(self.window, text=dat[1]).grid(row=index+1, column=0)
            Label(self.window, text=dat[2]).grid(row=index+1, column=1)
            Label(self.window, text=dat[3]).grid(row=index+1, column=2)
            Label(self.window, text=dat[4]).grid(row=index+1, column=3)
            Label(self.window, text=dat[5]).grid(row=index+1, column=4)
            self.btn_edit=Button(self.window, text ="Edit",bg="grey",fg="white", font=("Helvetica", 11),command = lambda i=dat[0]: self.edit_values(i))
            self.btn_edit.grid(row=index+1,column=5,pady=10)  
        self.btn_new=Button(self.window, text ="Add new Facility",bg="grey",fg="white", font=("Helvetica", 11),command = self.add_facility_window)
        self.btn_new.grid(row=index+2,column=2,pady=10) 
        self.btn_back=Button(self.window, text ="Back to main menu",bg="grey",fg="white", \
                                font=("Helvetica", 12),command=self.btn_back)
        self.btn_back.grid(row=index+2,column=3,pady=10,columnspan=2)  
    def add_facility_window(self):
        self.window.destroy()
        window = tkinter.Tk() 
        FacilityAdd(window,"Add New Facility")
    def edit_values(self,button_id):
        self.window.destroy()
        window = tkinter.Tk() 
        FacilityEdit(window,"Edit Facility",button_id)
    def btn_back(self):
        from MainMenu import MainMenu
        self.window.destroy()
        window = tkinter.Tk()   
        MainMenu(window, "Cargo Main Menu")  
class FacilityEdit:
    """FacilitiesEdit class can be used to edit particular facility"""
    def __init__(self, window, formtitle,fac_id):
        self.window = window
        self.window.title(formtitle)
        self.window.wm_minsize(550,550)
        self.lb_formtitle = Label(self.window, text="Edit facility",font=("Helvetica", 14)).grid(row=0,column=1)
        self.lb_facitype = Label(self.window, text="Type of Facility", )
        self.lb_facitype.grid(row=1, column=0,sticky=W,padx=15)
        self.lb_name = Label(self.window, text="Name",)
        self.lb_name.grid(row=2, column=0,sticky=W,padx=15)
        self.lb_connection = Label(self.window, text="Connection",)
        self.lb_connection.grid(row=3, column=0,sticky=W,padx=15)
        self.lb_distance = Label(self.window, text="Distance to Connection",)
        self.lb_distance.grid(row=4, column=0,sticky=W,padx=15)
        self.lb_connection_type = Label(self.window, text="Type of Connection",)
        self.lb_connection_type.grid(row=5, column=0,sticky=W,padx=15)
        self.btn_save=Button(self.window, text ="Save",bg="grey",fg="white", font=("Helvetica", 11),command = lambda: self.button_event('save',fac_id))
        self.btn_save.grid(row=6,column=0,pady=10)  
        # self.btn_cancel=Button(self.window, text ="Cancel",bg="grey",fg="white", font=("Helvetica", 11),command = lambda: self.button_event('cancel'))
        # self.btn_cancel.grid(row=6,column=1,pady=10)  
        self.btn_back=Button(self.window, text ="Back to list",bg="grey",fg="white", font=("Helvetica", 11),command = lambda: self.button_event('back',fac_id))
        self.btn_back.grid(row=6,column=1,pady=10,padx=20)  
        fetched_facility=self.fetch_fac_byid(fac_id)
        #var_facitype,var_name=tkinter.StringVar(),tkinter.StringVar()
        for facility in fetched_facility:
            self.txt_facitype = Entry(self.window, bd =5)
            self.txt_facitype.grid(row=1,column=1,padx=10,pady=10)
            self.txt_facitype.insert(0,facility[1])
            self.txt_name = Entry(self.window, bd =5)
            self.txt_name.grid(row=2,column=1,padx=10,pady=10)
            self.txt_name.insert(0,facility[2])
            self.txt_connection = Entry(self.window, bd =5)
            self.txt_connection.grid(row=3,column=1,padx=10,pady=10)
            self.txt_connection.insert(0,facility[3])
            self.txt_distance = Entry(self.window, bd =5)
            self.txt_distance.grid(row=4,column=1,padx=10,pady=10)
            self.txt_distance.insert(0,facility[4])
            self.txt_connection_type = Entry(self.window, bd =5)
            self.txt_connection_type.grid(row=5,column=1,padx=10,pady=10)
            self.txt_connection_type.insert(0,facility[5])
    def fetch_fac_byid(self,fac_id):
        query="SELECT * FROM [dbo].[Facility] where fac_id="+str(fac_id)
        dbObject=DbOperation()
        cursor=dbObject.exec_select_return_result(query)
        cursor.execute(query)
        data=cursor.fetchall()
        return data
    def button_event(self,button_id,fac_id):
        if button_id=='save':
            query="update [dbo].[Facility] set [fac_type]='%s',[name]='%s',[connection]='%s',[distance_to_connection]='%s',[type_of_connection]='%s' where [fac_id]=%d" % \
                  (self.txt_facitype.get(),self.txt_name.get(),self.txt_connection.get(),self.txt_distance.get(),self.txt_connection_type.get(),fac_id)
            dbObject=DbOperation()
            rows_affected=dbObject.insert_value(query)
            if rows_affected!=0:
                messagebox.showinfo("Info","Successfully saved the changes")
                self.window.destroy()
                window = tkinter.Tk()   
                Facilities(window, "Available facilities")
            else:
                messagebox.showinfo("Info","Sorry something went wrong")
        elif button_id=='back':
            self.window.destroy()
            window = tkinter.Tk()   
            fac = Facilities(window, "Available facilities")

class FacilityAdd:
    """FacilitiesAdd class can be used to add new facility"""
    def __init__(self, window, formtitle):
        self.window = window
        self.window.title(formtitle)
        self.window.wm_minsize(500,400)
        self.lb_formtitle = Label(self.window, text="Add New Facility",font=("Helvetica", 14)).grid(row=0,column=1)
        self.lb_facitype = Label(self.window, text="Type of Facility", )
        self.lb_facitype.grid(row=1, column=0,sticky=W,padx=15)
        self.txt_facitype = Entry(self.window, bd =5)
        self.txt_facitype.grid(row=1,column=1,padx=10,pady=10)
        self.lb_name = Label(self.window, text="Name",)
        self.lb_name.grid(row=2, column=0,sticky=W,padx=15)
        self.txt_name = Entry(self.window, bd =5)
        self.txt_name.grid(row=2,column=1,padx=10,pady=10)
        self.lb_connection = Label(self.window, text="Connection",)
        self.lb_connection.grid(row=3, column=0,sticky=W,padx=15)
        self.txt_connection = Entry(self.window, bd =5)
        self.txt_connection.grid(row=3,column=1,padx=10,pady=10)
        self.lb_distance = Label(self.window, text="Distance to Connection",)
        self.lb_distance.grid(row=4, column=0,sticky=W,padx=15)
        self.txt_distance = Entry(self.window, bd =5)
        self.txt_distance.grid(row=4,column=1,padx=10,pady=10)
        self.lb_connection_type = Label(self.window, text="Type of Connection",)
        self.lb_connection_type.grid(row=5, column=0,sticky=W,padx=15)
        self.txt_connection_type = Entry(self.window, bd =5)
        self.txt_connection_type.grid(row=5,column=1,padx=10,pady=10)
        self.btn_save=Button(self.window, text ="Save",bg="grey",fg="white", font=("Helvetica", 11),command = lambda: self.btn_add_facility('save1'))
        self.btn_save.grid(row=6,column=0,pady=10) 
        self.btn_back=Button(self.window, text ="Back to list",bg="grey",fg="white", font=("Helvetica", 11),command = lambda: self.btn_add_facility('back1'))
        self.btn_back.grid(row=6,column=1,pady=10,padx=20)
    def btn_add_facility(self,button_id):
        if button_id=='save1':
            dbObject=DbOperation()
            query="INSERT INTO [dbo].[Facility] VALUES ('%s', '%s', '%s', '%s','%s')" % \
            (self.txt_facitype.get(),self.txt_name.get(),self.txt_connection.get(),self.txt_distance.get(),self.txt_connection_type.get())
            rows_affected1=dbObject.insert_value(query)
            if rows_affected1!=0:
                messagebox.showinfo("Info","New facility added successfully")
                self.window.destroy()
                window = tkinter.Tk()   
                Facilities(window, "Available facilities")
            else:
                messagebox.showinfo("Info","Sorry something went wrong")
        elif(button_id=='back1'):
            self.window.destroy()
            window = tkinter.Tk()   
            fac = Facilities(window, "Available facilities")
# window = tkinter.Tk()   
# fac = Facilities(window, "Available facilities")
# window.mainloop()
