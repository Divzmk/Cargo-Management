from tkinter import *
import tkinter
from tkinter import ttk 
from tkinter import messagebox
from DbOperation import DbOperation

class DepotStock:
    def __init__(self, window, formtitle):
        self.window = window
        self.window.title(formtitle)
        self.window.wm_minsize(500,500)
        # self.lb_formtitle = Label(self.window, text="Depot Stock levels",font=("Helvetica", 14)).pack(side=tkinter.TOP,fill=tkinter.X) 
        self.lb_formtitle = Label(self.window, text="Depot Stock levels",font=("Helvetica", 14)).grid(row=0,column=1) 
        # Using treeview widget 
        treev = ttk.Treeview(self.window) 
        # treev.pack(side=tkinter.TOP,fill=tkinter.X) 
        treev.grid(row=1,column=0,columnspan=3)
        # Defining number of columns 
        treev["columns"] = ("1", "2", "3") 
  
        # Defining heading 
        treev['show'] = 'headings'
  
        # Assigning the width and anchor to  the respective columns 
        treev.column("1", width = 170, anchor ='c') 
        treev.column("2", width = 170, anchor ='c') 
        treev.column("3", width = 170, anchor ='c') 
  
        # Assigning the heading names to the  respective columns 
        treev.heading("1", text ="Depot Name") 
        treev.heading("2", text ="Item") 
        treev.heading("3", text ="Instock quantity(Kg)") 
        query="SELECT [depot_name],[item],[quantity] FROM [dbo].[Depot_stock]"
        dbObject=DbOperation()
        cursor=dbObject.exec_select_return_result(query)
        cursor.execute(query)
        result=cursor.fetchall()
        index = iid = 0
        for row in result:
            treev.insert("", index, iid, values=tuple(row))
            index = iid = index + 1
        self.btn_back=Button(self.window, text ="Back to main menu",bg="grey",fg="white", \
                                font=("Helvetica", 12),command=self.btn_back)
        self.btn_back.grid(row=2,column=1,pady=10)  
    def btn_back(self):
        from MainMenu import MainMenu
        self.window.destroy()
        window = tkinter.Tk()   
        MainMenu(window, "Cargo Main Menu")   
# window = tkinter.Tk()   
# login = DepotStock(window, "Depot stock levels")
# window.mainloop()
        